import find_score
import random
import copy

def optimize_device(input_gates, circuit, dtype, N = 125, D = 1):
	random.seed(10)
	edit_ops = ["Stretch", "IncSlope", "DecSlope", "StrongerProm", "WeakerProm", "StrongerRBS", "WeakerRBS"]
	circuit_score = find_score.find_score(input_gates, circuit, dtype)
	temp_circuits = []
	improve = []
	improve_scores = []
	delta = D
	iter_circuit = circuit
	print("Processing a lot")
	for i in range(N):
		#print("iter: ",circuit.score)
		for k in range(len(circuit.gates)): #generates circuits
			for ops in edit_ops:
				temp_circuit = copy.deepcopy(iter_circuit)
				temp_circuit.gates[k].change_param(ops, delta)
				temp_circuit.hill_response();
				temp_circuits.append(temp_circuit)
		for tc in temp_circuits:
			tc_score = find_score.find_score(input_gates, tc, dtype)
			if (tc_score > circuit_score):
				#print("changed:", tc_score, circuit_score)
				improve.append(tc)
				improve_scores.append(tc.score)
				#print(tc.score)

		delta = delta + random.uniform(-0.2, 0.2)
	max_imp = max(improve_scores)
	max_idx = improve_scores.index(max_imp)
	return improve[max_idx]




	#circuit_score = find_score.find_score(input_gates, iter_circuit, dtype)
	#print("final: ",circuit_score)










