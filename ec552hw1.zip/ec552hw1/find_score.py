import math
def find_score(input_sensors, circuit, dtype):
	# gather the input values from sensors
	sensor_vals = []
	for sensor in input_sensors:
		sensor_vals.append([sensor.parameters[1]["value"], sensor.parameters[0]["value"]])

	#print(sensor_vals)

	in_vals = []
	in_vals.append([sensor_vals[0][0], sensor_vals[1][0], sensor_vals[2][0]])
	in_vals.append([sensor_vals[0][0], sensor_vals[1][0], sensor_vals[2][1]])
	in_vals.append([sensor_vals[0][0], sensor_vals[1][1], sensor_vals[2][0]])
	in_vals.append([sensor_vals[0][0], sensor_vals[1][1], sensor_vals[2][1]])
	in_vals.append([sensor_vals[0][1], sensor_vals[1][0], sensor_vals[2][0]])
	in_vals.append([sensor_vals[0][1], sensor_vals[1][0], sensor_vals[2][1]])
	in_vals.append([sensor_vals[0][1], sensor_vals[1][1], sensor_vals[2][0]])
	in_vals.append([sensor_vals[0][1], sensor_vals[1][1], sensor_vals[2][1]])

	#print(in_vals)
	exp_vals = []
	for count, vals in enumerate(in_vals):
		#print(count)
		#print(vals[1], vals[0])
		circuit.in_vals = vals
		for gate in circuit.gates:
			if(gate.in1 == "a"):
				circuit.make_connection(gate, "v0i1")
			if(gate.in1 == "b"):
				circuit.make_connection(gate, "v1i1")
			if(gate.in1 == "c"):
				circuit.make_connection(gate, "v2i1")
			if(gate.in2 == "a"):
				circuit.make_connection(gate, "v0i2")
			if(gate.in2 == "b"):
				circuit.make_connection(gate, "v1i2")
			if(gate.in2 == "c"):
				circuit.make_connection(gate, "v2i2")
		circuit.hill_response()
		#circuit.gates[0].print_gate()
		exp_vals.append(circuit.gates[-1].out)
	#print(exp_vals)

	if (dtype == 0):
		bools = [1, 1, 1, 1, 0, 1, 0, 1]
	elif (dtype == 1):
		bools = [0, 0, 1, 1, 1, 1, 0, 0]
	elif (dtype == 2):
		bools = [0, 0, 1, 1, 1, 1, 1, 1]

	#find lows and highs
	low_list = []
	high_list = []
	for idx, bol in enumerate(bools):
		if ( bol == 0):
			low_list.append(exp_vals[idx])
		else:
			high_list.append(exp_vals[idx])
	score = math.log((min(high_list)/max(low_list)),10)
	#print(score)
	circuit.score = score
	return score

