class circuit:
    def __init__(self):
        self.gates = []
        self.in_vals = [0, 0, 0]
        self.score = None
    def add_gate(self,gate):
        self.gates.append(gate)
    def remove_gate(self, gate_index):
        self.gates.pop(gate_index)
    def gate_list(self):
        print ("\nCurrent elements in the device:")
        for count, gate in enumerate(self.gates):
            print (count,gate.name)
    def make_connection(self, gate1, wire, gate2 = None):
        if (wire == "o1i1"):
            gate1.out1 = gate2.name
            gate2.in1 = gate1.name
            gate2.x1=gate1.out
        elif(wire == "o1i2"):
            gate1.out1 = gate2.name
            gate2.in2 = gate1.name
            gate2.x2=gate1.out
        elif(wire == "o2i1"):
            gate1.out2 = gate2.name
            gate2.in1 = gate1.name
            gate2.x1=gate1.out
        elif(wire == "o2i2"):
            gate1.out2 = gate2.name
            gate2.in2 = gate1.name
            gate2.x2=gate1.out
        elif(wire == "v0i1"):
            gate1.x1 = self.in_vals[0]
            gate1.in1 = "a"
            #print("a assigned")
            gate1.hill_response()
        elif(wire == "v1i1"):
            gate1.x1 = self.in_vals[1]
            gate1.in1 = "b"
            gate1.hill_response()
        elif(wire == "v2i1"):
            gate1.x1 = self.in_vals[2] 
            gate1.in1 = "c"
            gate1.hill_response()   
        elif(wire == "v0i2"):
            gate1.x2 = self.in_vals[0]
            gate1.in2 = "a"
            gate1.hill_response()
        elif(wire == "v1i2"):
            gate1.x2 = self.in_vals[1]
            gate1.in2 = "b"
            #print("b assigned")
            gate1.hill_response()
        elif(wire == "v2i2"):
            gate1.x2 = self.in_vals[2] 
            gate1.in2 = "c"
            gate1.hill_response()    
    def print_connections(self):
        print("Printing connections")
        for gate in self.gates:
            gate.print_connections()
    def print_device(self):
        print("Printing device")
        for gate in self.gates:
            gate.print_gate()
    def hill_response(self):
        for num,gate in enumerate(self.gates):
            gate.hill_response(); 
            # new out value generated so we need to determine which gates are connect 

            #print("Gate: ",num)
            for update_gate in self.gates:
                if(update_gate.in1 == gate.name):
                    update_gate.x1 = gate.out 
                    #print("Gate: ",update_gate.name," updated")
                if(update_gate.in2 == gate.name):
                    update_gate.x2 = gate.out
                    #print("Gate: ",update_gate.name," updated")
            #gate.print_gate()
        #print(self.gates[-1].name,self.gates[-1].out)


class gate:
    def __init__(self, model_dict, out1 = None ,  in1= None , out2 = None,in2 = None, bool_gate = None):

        self.name = model_dict["name"]
        self.functions = model_dict["functions"]
        self.parameters = model_dict["parameters"]

        #self.gate = model_dict
        self.out1 = out1
        self.out2 = out2
        self.in1 = in1
        self.in2 = in2
        self.bool_gate = bool_gate
        self.x1=None
        self.x2=None
        self.x=None
        self.out = None

    def print_gate(self):
        print("Printing gate", self.name)
        print("Functions: " ,self.functions)
        print("Parameters: ", self.parameters)
        print("out1: ", self.out1)
        print("out2: ",self.out2)
        print("in1:  ",self.in1)
        print("in2:  ",self.in2)
        print("boolean gate: " ,self.bool_gate)
        print("x1: ",self.x1)
        print("x2: ",self.x2)
        print("output: ",self.out)

    def print_connections(self):
        print( self.name)
        print("in1:  ",self.in1)
        print("in2:  ",self.in2)
        print("out1: ", self.out1)
        print("out2: ",self.out2)


    def change_param(self, function, value):
            if (function=="Stretch" or function==0):
                ymax=self.parameters[0]
                if ymax['name']=="ymax":
                    dummy=ymax['value']
                    ymax['value']=value*dummy
                self.parameters[0]=ymax
                    
                ymin=self.parameters[1]
                if ymin['name']=='ymin':
                    dummy=ymin['value']
                    ymin['value']=dummy/value
                self.parameters[1]=ymin
                    
            elif (function=="IncSlope" or function==1):
                slope=self.parameters[3]
                if slope['name']=='n':
                    dummy=slope['value']
                    slope['value']=dummy*value
                self.parameters[3]=slope

            elif (function=="DecSlope" or function==2):
                slope=self.parameters[3]
                if slope['name']=='n':
                    dummy=slope['value']
                    slope['value']=dummy/value
                self.parameters[3]=slope

            elif (function=="StrongerProm" or function==3):
                ymax=self.parameters[0]
                if ymax['name']=="ymax":
                    dummy=ymax['value']
                    ymax['value']=value*dummy
                self.parameters[0]=ymax
                    
                ymin=self.parameters[1]
                if ymin['name']=='ymin':
                    dummy=ymin['value']
                    ymin['value']=dummy*value
                self.parameters[1]=ymin

            elif (function=="WeakerProm" or function==4):
                ymax=self.parameters[0]
                if ymax['name']=="ymax":
                    dummy=ymax['value']
                    ymax['value']=dummy/value
                self.parameters[0]=ymax
                    
                ymin=self.parameters[1]
                if ymin['name']=='ymin':
                    dummy=ymin['value']
                    ymin['value']=dummy/value
                self.parameters[1]=ymin

            elif (function=="StrongerRBS" or function==5):
                k=self.parameters[2]
                if k['name']=="K":
                    dummy=k['value']
                    k['value']=value*dummy
                self.parameters[2]=k

            elif (function=="WeakerRBS" or function==6):
                k=self.parameters[2]
                if k['name']=="K":
                    dummy=k['value']
                    k['value']=dummy/value
                self.parameters[2]=k

                
                
    def hill_response(self):
        ymax = self.parameters[0]["value"]
        ymin = self.parameters[1]["value"]
        K = self.parameters[2]["value"]
        n = self.parameters[3]["value"]
        # if type(self.x1)==float or type(self.x1)==int:
        #     if type(self.x2)!=float or type(self.x2)!=int:
        #         self.out = self.parameters[1]["value"] + (self.parameters[0]["value"] - self.parameters[1]["value"]) / (1.0 + (self.x1 / self.parameters[2]["value"])**self.parameters[3]["value"])
        # elif type(self.x2)==float or type(self.x2)==int:
        #     if type(self.x1)!=float or type(self.x1)!=int:
        #         self.out = self.parameters[1]["value"] + (self.parameters[0]["value"] - self.parameters[1]["value"]) / (1.0 + (self.x2 / self.parameters[2]["value"])**self.parameters[3]["value"])
        # elif (type(self.x1)==float or type(self.x1)==int) and (type(self.x2)==float or type(self.x2)==int):
        #     self.out = self.parameters[1]["value"] + (self.parameters[0]["value"] - self.parameters[1]["value"]) / (1.0 + ((self.x1+self.x2) / self.parameters[2]["value"])**self.parameters[3]["value"])
        # else:
        #     self.out = self.parameters[1]["value"] + (self.parameters[0]["value"] - self.parameters[1]["value"]) / (1.0 + (self.x / self.parameters[2]["value"])**self.parameters[3]["value"])            

        if ((self.x1 is None) and (self.x2 is None)):
            x = self.x
        elif ((self.x1 is None) and (self.x2 is not None)):
            x = self.x2
        elif ((self.x1 is not None) and (self.x2 is None)):
            x = self.x1
        elif ((self.x1 is not None) and (self.x2 is not None)):
            x = self.x1 + self.x2
        self.out = ymin + (ymax - ymin)/(1 + (x/ K)*n)

        return self.out
