EC552 HW1 Jonathan Ngo and Pablo Saucedo

Required input files:
- UCF.json
- input.json

Example input of changing gates in a library, and optimizing a device:

SC1C1G1T1.UCF.json
4 2 1
6
1.2
N
N
SC1C1G1T1.input.json
11 10 2 4 1
100
0.9
N
