# # pull in a library of choice
#	- convert dictionaries to gate class
# 	- show list of options
# 	- change gates individually or all at once
# 	- save file?
# # make a circuit from those gates
# 	- allow user to define connections. make changes.
#  	- develop an initial score
# # iterate through an optimization algorithm
#  	- show score progress
#  	- truth tables?
# # allow user to choose output type

import json
import make_device
import find_score
import math
import optimize_circuit_brute
#open the ucf library
print("Please import a library: \n")
file = input()
f = open(file)
sc = json.load(f)

#parse list dict into smaller lists
print("Processing data file :') ")
MTFL 	= list()
GTES 	= list()
MDLS 	= list()
STRSS 	= list()
PRTS	= list()
FNCS 	= list()
MISC	= list()

for i in sc:
	name = i.get("collection")
	if (name == "motif_library"):
		MTFL.append(i)
	elif (name == "gates"):
		GTES.append(i)
	elif (name == "models"):
		MDLS.append(i)
	elif (name == "structures"):
		STRSS.append(i)
	elif (name == "parts"):
		PRTS.append(i)
	elif (name == "functions"):
		FNCS.append(i)
	else:
		MISC.append(i)

#extra  processing for fnc list
hill_rsp 	= FNCS[0]
lin_in_comp = FNCS[1]
del FNCS[0]
del FNCS[0]
f.close()

# convert model dictionaries to classes
options = [];

print("\nHere is the list of available gates: ")
for count, model in enumerate(MDLS):
	#print(gate["name"])
	options.append(make_device.gate(model))
	print(count,model["name"])
	#print(options[count].print_gate())

gate_edit = True
op_edit = True
edit_list = [];
edit_ops = ["Stretch", "IncSlope", "DecSlope", "StrongerProm", "WeakerProm", "StrongerRBS", "WeakerRBS"]
while gate_edit:
	print("\nPlease choose gate(s) to edit")
	input_string = input("Enter gate numbers separated by space: ")
	#input_string = "0 5"
	edit_integers = input_string.split()
	edit_integers = [int(x) for x in edit_integers]
	edit_list = [options[index] for index in edit_integers]

	print("\nHere is the list of selected gates: ")
	for i , edit_list_gate  in enumerate(edit_list):
		print(edit_integers[i], edit_list_gate.name)
	op_edit = True
	while op_edit:	
		print("\nWhat do you want to edit?")
		for count, edit_op in enumerate(edit_ops):
			print(count, edit_op)
		op_num = input("Enter operation number: ")
		#op_num = "2"
		op_num = int(op_num)
		op_value = input ("Enter operation value: ")
		#op_value = "1"
		op_value = float(op_value)

		for edit_list_gate in edit_list:
			edit_list_gate.change_param(edit_ops[op_num], op_value)

		choice = input("Perform more operations on selected gates? ") #input Y or N
		#choice = "N"
		if (choice == "N"):
			op_edit = False
	choice = input("Choose different gates? ") #input Y or N
	#choice = "N"
	if (choice == "N"):
		gate_edit = False
	if (choice == "Y"):
		op_edit == True


device1 = make_device.circuit()

# Extract input senor models
in_file = input("Import input library: ")
in_f = open(in_file) # do some file stuff later for on the fly options
in_sc = json.load(in_f)

IN_MDLS = list();
for i in in_sc:
	name = i.get("collection")
	if (name == "models"):
		IN_MDLS.append(i)
input_gates = []
for k, in_model in enumerate(IN_MDLS):
	#device1.add_gate(make_device.gate(in_model))
	input_gates.append(make_device.gate(in_model))
	input_gates[k].out = input_gates[k].parameters[1]["value"] # initial value set to ymin
in_f.close()

print("\nWhich gates do you want to add to the circuit?")

input_string = input("Enter gate numbers separated by space: ")
#input_string = "0 1"
device_integers = input_string.split()
device_integers = [int(x) for x in device_integers]
device_list = [options[index] for index in device_integers]

print("\nHere is the list of selected gates: ")
for i , device_list_gate  in enumerate(device_list):
	print(device_integers[i], device_list_gate.name)
	device1.add_gate(device_list_gate)
print(device1.gate_list())


# Make the device
print("\nDefining how connections are made")

connecting_device = True
while connecting_device:
	# [c ,b, a]
	N = input("Enter number of iterations: ")
	N= int(N)
	D = input("Enter delta: ")
	D= float(D)
	if (len(device1.gates) == 3):
		print("T-table: [1, 1, 1, 1, 0, 1, 0, 1]")
		device1.make_connection(device1.gates[0], 'v0i1')
		device1.make_connection(device1.gates[1], 'v2i2')
		device1.make_connection(device1.gates[0], 'o1i1', device1.gates[1])
		device1.gates[1].hill_response()
		device1.make_connection(device1.gates[1], 'o1i1', device1.gates[2])
		device1.gates[2].hill_response()
		device1.print_connections()
		print("\nInitial score: ",find_score.find_score(input_gates, device1, 0))
		device1 = optimize_circuit_brute.optimize_device(input_gates, device1, 0, N, D);
		print("\nOptimized score: ",find_score.find_score(input_gates, device1, 0))
	elif (len(device1.gates) == 5):
		print("T-table: [0, 0, 1, 1, 1, 1, 0, 0]")
		device1.make_connection(device1.gates[0], 'v0i1')
		device1.make_connection(device1.gates[3], 'v0i1')
		device1.make_connection(device1.gates[1], 'v1i1')
		device1.make_connection(device1.gates[3], 'v1i2')
		device1.make_connection(device1.gates[0], 'o1i1', device1.gates[2])
		device1.make_connection(device1.gates[1], 'o1i2', device1.gates[2])
		device1.make_connection(device1.gates[3], 'o1i2', device1.gates[4])
		device1.make_connection(device1.gates[2], 'o1i1', device1.gates[4])
		device1.hill_response()
		device1.print_connections()
		print("\nInitial score: ",find_score.find_score(input_gates, device1, 1))
		device1 = optimize_circuit_brute.optimize_device(input_gates, device1, 1, N, D);
		print("\nOptimized score: ",find_score.find_score(input_gates, device1, 1))
	elif (len(device1.gates) == 2):
		print("T-table: [0, 0, 1, 1, 1, 1, 1, 1]")
		device1.make_connection(device1.gates[0], 'v0i1')
		device1.make_connection(device1.gates[0], 'v1i2')
		device1.make_connection(device1.gates[0], 'o1i1', device1.gates[1])
		device1.print_connections()
		print("\nInitial score: ",find_score.find_score(input_gates, device1, 2))
		device1 = optimize_circuit_brute.optimize_device(input_gates, device1, 2, N, D);
		print("\nOptimized score: ",find_score.find_score(input_gates, device1, 2))
	ask = input("Make more devices?: ")
	if ask == "N":
		connecting_device = False
		print("Reporting...")
		device1.print_connections()
		device1.print_device()


