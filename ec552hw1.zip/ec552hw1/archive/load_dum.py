import json


device=open('Bth1C1G1T1.UCF.json')

dish = json.load(device)
outfile = open("test.json","w")
json.dump(dish,outfile,indent = 4)

device.close()
outfile.close()
