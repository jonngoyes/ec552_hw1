import json
file=int(input("Enter the number of which library you would like to modify\n1.)Bth1C1G1T1.UCF\n2.)Eco1C1G1T1.UCF\n3.)Eco1C2G2T2.UCF\n4.)Eco1C1G3T1.UCF\n5.)SC1C1G1T1.UCF\n"))
if file==1:
    device=open('Bth1C1G1T1.UCF.json')
if file==2:
    device=open('Eco1C1G1T1.UCF.json')
if file==3:
    device=open('Eco1C2G2T2.UCF.json')
if file==4:
    device=open('Eco2C1G3T1.UCF.json')
if file==5:
    device=open('SC1C1G1T1.UCF.json')
data=json.load(device)
outfile = open("Modified.json","w")
#json.dump(data,outfile, indent=4)
#fisk=open('Modified.json')

model=(item for item in data if item['collection']=='models')
print('The available models are:')
for item in model:
    print(item['name'])


stretch=input("\nWhich one of these would you like to stretch?\nFor all type ALL\nFor NONE type NEXT\n")
if stretch!=('NEXT'):
    x=float(input("\nHow much would you like to stretch them?(Can be 1.5 at most)\n"))
    model=(item for item in data if item['collection']=='models')
    al=('ALL')
    if stretch==al:
        for item in model:
            print("\nFor", item['name'])
            parameters=(item['parameters'])
            ymax_old=(item for item in parameters if item['name']=='ymax')
            ymin_old=(item for item in parameters if item['name']=='ymin')
            for item in ymax_old:
                ymax=item['value']*x
                print('\nYmax was', item['value'], 'and was changed to', ymax)
                #print((item['value']))
                #item['value']=item['value'].replace(item['value'],str(ymax)) 
                item['value'] = ymax
                #print((item['value']))

            for item in ymin_old:
                ymin=item['value']/x
                print('Ymin was', item['value'], 'and was changed to', ymin,'\n')
                #item['value']=item['value'].replace(item['value'],str(ymin))
                item['value'] = ymin
    else:
        for item in model:
            if item['name']==stretch:
                print("\nFor", item['name'])
                parameters=(item['parameters'])
                ymax_old=(item for item in parameters if item['name']=='ymax')
                ymin_old=(item for item in parameters if item['name']=='ymin')
                for item in ymax_old:
                    ymax=item['value']*x
                    print('Ymax was', item['value'], 'and was changed to', ymax)
                    #item['value']=item['value'].replace(item['value'],str(ymax))
                    item['value'] = ymax
                for item in ymin_old:
                    ymin=item['value']/x
                    print('Ymin was', item['value'], 'and was changed to', ymin)
                    #item['value']=item['value'].replace(item['value'],str(ymin))
                    item['value'] = ymin



slope_direction=input("\nWould you like to change slope? \nIf increase, type INC\nIf decrease, type DEC\n if both, type BOTH, if Neither, type NEXT\n")
if slope_direction!=('NEXT'):
    if slope_direction!=('DEC'):
        slope_inc=input('\nFor which one of these would you like to increase slope?\nFor all type ALL\n')
        x=float(input("\nHow much would you like to increase slope?(Can be 1.05 at most)\n"))
        model=(item for item in data if item['collection']=='models')
        al=('ALL')
        if slope_inc==al:
            for item in model:
                print("\nFor", item['name'])
                parameters=(item['parameters'])
                slope_old=(item for item in parameters if item['name']=='n')
                for item in slope_old:
                    slopeinc=item['value']*x
                    print('\nSlope was', item['value'], 'and was changed to', slopeinc)
                    #item['value']=item['value'].replace(slopeinc)
                    item['value']=slopeinc
        else:
            for item in model:
                if item['name']==slope_inc:
                    print("\nFor", item['name'])
                    parameters=(item['parameters'])
                    slope_old=(item for item in parameters if item['name']=='n')
                    for item in slope_old:
                        slopeinc=item['value']*x
                        print('Slope was', item['value'], 'and was changed to', slopeinc)
                        #item['value']=item['value'].replace(slopeinc)
                        item['value']=slopeinc

    if slope_direction!=('INC'):
        slope_dec=input("\nFor which one of these would you like to decrease slope?\nFor all type ALL\n")
        if slope_dec!=('NEXT'):
            x=float(input("\nHow much would you like to decrease slope?(Can be 1.05 at most)\n"))
            model=(item for item in data if item['collection']=='models')
            al=('ALL')
            if slope_dec==al:
                for item in model:
                    print("\nFor", item['name'])
                    parameters=(item['parameters'])
                    slope_old=(item for item in parameters if item['name']=='n')
                    for item in slope_old:
                        slopedec=item['value']/x
                        print('\nSlope was', item['value'], 'and was changed to', slopedec)
                        item['value']=item['value'].replace(slopedec)
                        item['value']= slopedec
            else:
                for item in model:
                    if item['name']==slope_dec:
                        print("\nFor", item['name'])
                        parameters=(item['parameters'])
                        slope_old=(item for item in parameters if item['name']=='n')
                        for item in slope_old:
                            slopedec=item['value']/x
                            print('Slope was', item['value'], 'and was changed to', slopedec)
                            #item['value']=item['value'].replace(slopedec)
                            item['value']=slopedec

                        

prom_direction=input("\nWould you like to change promoter strength? \nIf increase, type INC\nIf decrease, type DEC\n if both, type BOTH, if Neither, type NEXT\n")
if prom_direction!=('NEXT'):
    if prom_direction!=('DEC'):
        prom_inc=input('\nFor which one of these would you like to increase promoter strength?\nFor all type ALL\n')
        x=float(input("\nHow much would you like to increase promoter strength?\n"))
        model=(item for item in data if item['collection']=='models')
        al=('ALL')
        if prom_inc==al:
            for item in model:
                print("\nFor", item['name'])
                parameters=(item['parameters'])
                old_ymax=(item for item in parameters if item['name']=='ymax')
                old_ymin=(item for item in parameters if item['name']=='ymin')
                for item in old_ymax:
                    prominc=item['value']*x
                    print('\nYmax was', item['value'], 'and was changed to', prominc)
                    # item['value']=item['value'].replace(prominc)
                    item['value']=prominc
                for item in old_ymin:
                    prominc=item['value']*x
                    print('\nYmin was', item['value'], 'and was changed to', prominc)
                    #item['value']=item['value'].replace(prominc)
                    item['value']=prominc
                    
        else:
            for item in model:
                print("\nFor", item['name'])
                parameters=(item['parameters'])
                old_ymax=(item for item in parameters if item['name']=='ymax')
                old_ymin=(item for item in parameters if item['name']=='ymin')
                for item in old_ymax:
                    prominc=item['value']*x
                    print('\nYmax was', item['value'], 'and was changed to', prominc)
                    #item['value']=item['value'].replace(prominc)
                    item['value']=prominc
                for item in old_ymin:
                    prominc=item['value']*x
                    print('\nYmin was', item['value'], 'and was changed to', prominc)
                    #item['value']=item['value'].replace(prominc)
                    item['value']=prominc
                    

    if prom_direction!=('INC'):
        prom_dec=input('\nFor which one of these would you like to decrease promoter strength?\nFor all type ALL\n')
        x=float(input("\nHow much would you like to increase promoter strength?\n"))
        model=(item for item in data if item['collection']=='models')
        al=('ALL')
        if prom_dec==al:
            for item in model:
                print("\nFor", item['name'])
                parameters=(item['parameters'])
                old_ymax=(item for item in parameters if item['name']=='ymax')
                old_ymin=(item for item in parameters if item['name']=='ymin')
                for item in old_ymax:
                    promdec=item['value']/x
                    print('\nYmax was', item['value'], 'and was changed to', promdec)
                    #item['value']=item['value'].replace(promdec)
                    item['value']=promdec
                for item in old_ymin:
                    promdec=item['value']/x
                    print('\nYmin was', item['value'], 'and was changed to', promdec)
                    #item['value']=item['value'].replace(promdec)
                    item['value']=promdec
                    
        else:
            for item in model:
                print("\nFor", item['name'])
                parameters=(item['parameters'])
                old_ymax=(item for item in parameters if item['name']=='ymax')
                old_ymin=(item for item in parameters if item['name']=='ymin')
                for item in old_ymax:
                    promdec=item['value']/x
                    print('\nYmax was', item['value'], 'and was changed to', promdec)
                    #item['value']=item['value'].replace(promdec)
                    item['value']=promdec
                for item in old_ymin:
                    promdec=item['value']/x
                    print('\nYmin was', item['value'], 'and was changed to', promdec)
                    #item['value']=item['value'].replace(promdec)
                    item['value']=promdec

RBS_direction=input("\nWould you like to change RBS strength? \nIf increase, type INC\nIf decrease, type DEC\n if both, type BOTH, if Neither, type NEXT\n")
if RBS_direction!=('NEXT'):
    if RBS_direction!=('DEC'):
        RBS_inc=input('\nFor which one of these would you like to increase RBS strength?\nFor all type ALL\n')
        x=float(input("\nHow much would you like to increase RBS strength?\n"))
        model=(item for item in data if item['collection']=='models')
        al=('ALL')
        if RBS_inc==al:
            for item in model:
                print("\nFor", item['name'])
                parameters=(item['parameters'])
                RBS_old=(item for item in parameters if item['name']=='K')
                for item in RBS_old:
                    RBSinc=item['value']*x
                    print('\nSlope was', item['value'], 'and was changed to', RBSinc)
                    #item['value']=item['value'].replace(RBSinc)
                    item['value']=RBSinc
        else:
            for item in model:
                if item['name']==RBS_inc:
                    print("\nFor", item['name'])
                    parameters=(item['parameters'])
                    RBS_old=(item for item in parameters if item['name']=='K')
                    for item in RBS_old:
                        RBSinc=item['value']*x
                        print('\nRBS was', item['value'], 'and was changed to', RBSinc)
                        #item['value']=item['value'].replace(RBSinc)
                        item['value']=RBSinc

    if RBS_direction!=('INC'):
        RBS_dec=input("\nFor which one of these would you like to decrease RBS strength?\nFor all type ALL\n")
        if RBS_dec!=('NEXT'):
            x=float(input("\nHow much would you like to decrease RBS strength?\n"))
            model=(item for item in data if item['collection']=='models')
            al=('ALL')
            if RBS_dec==al:
                for item in model:
                    print("\nFor", item['name'])
                    parameters=(item['parameters'])
                    RBS_old=(item for item in parameters if item['name']=='n')
                    for item in RBS_old:
                        RBSdec=item['value']/x
                        print('\nRBS was', item['value'], 'and was changed to', RBSdec)
                        #item['value']=item['value'].replace(RBSdec)
                        item['value']=RBSdec
            else:
                for item in model:
                    if item['name']==RBS_dec:
                        print("\nFor", item['name'])
                        parameters=(item['parameters'])
                        RBS_old=(item for item in parameters if item['name']=='n')
                        for item in RBS_old:
                            RBSdec=item['value']/x
                            print('Slope was', item['value'], 'and was changed to', RBSdec)
                            #item['item']=item['value'].replace(RBSdec)
                            item['value']=RBSdec
json.dump(data,outfile, indent=4)              
device.close()
outfile.close()