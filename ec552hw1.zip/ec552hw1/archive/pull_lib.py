import json
import make_device

#open the ucf library
print("Please import a library: \n")
f = open('SC1C1G1T1.UCF.json')
sc = json.load(f)

#parse list dict into smaller lists
print("Processing data file :') ")
MTFL 	= list()
GTES 	= list()
MDLS 	= list()
STRSS 	= list()
PRTS	= list()
FNCS 	= list()
MISC	= list()

for i in sc:
	name = i.get("collection")
	if (name == "motif_library"):
		MTFL.append(i)
	elif (name == "gates"):
		GTES.append(i)
	elif (name == "models"):
		MDLS.append(i)
	elif (name == "structures"):
		STRSS.append(i)
	elif (name == "parts"):
		PRTS.append(i)
	elif (name == "functions"):
		FNCS.append(i)
	else:
		MISC.append(i)

#extra  processing for fnc list
hill_rsp 	= FNCS[0]
#print(hill_rsp)
lin_in_comp = FNCS[1]
del FNCS[0]
del FNCS[0]
print(len(MDLS))
f.close()

#print(len(MTFL),len(GTES), len(MDLS), len(STRSS), len(PRTS), len(FNCS), len(MISC))
#print(FNCS[0]["table"])

# import matplotlib.pyplot as plt
# plt.plot(FNCS[0]["table"]["x"],FNCS[0]["table"]["output"])
# plt.xscale('log')
# plt.yscale('log')
# plt.ylabel('some numbers')
# plt.show()

# making a device:

gate1 = make_device.gate(MDLS[0])
gate2 = make_device.gate(MDLS[1])
gate3 = make_device.gate(MDLS[2])
gate4 = make_device.gate(MDLS[3])
gate5 = make_device.gate(MDLS[4])
device1 = make_device.circuit()
device1.add_gate(gate1)
device1.add_gate(gate2)
device1.add_gate(gate3)
device1.add_gate(gate4)
device1.add_gate(gate5)

#gate 1 processing and sending
gate1.x = 0.1;
gate1.hill_response()
device1.make_connection(gate1, "o1i1", gate2)
print("Gate 1 output",gate1.out)

#gate 2 processing and sending
gate2.change_param("StrongerProm",1.3)
gate2.hill_response()
print("Gate 2 output", gate2.out)
device1.make_connection(gate2, "o1i1", gate3)
device1.make_connection(gate2, "o2i1", gate4)

#gate 3 processing and sending
gate3.hill_response()
print("Gate 3 output",gate3.out)
device1.make_connection(gate3, "o1i1", gate5)

#gate 4 processing and sending
gate4.hill_response()
print ("Gate 4 output", gate4.out)
device1.make_connection(gate4, "o1i2", gate5)

#gate 5 output
gate5.hill_response()
print("Gate 5, final output is:", gate5.out)
