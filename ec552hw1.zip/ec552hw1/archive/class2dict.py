#class conversion t

class dict2class(object):
	def __init__(self, dicts):
		for key in dicts:
			setattr(self, key, dicts[key])